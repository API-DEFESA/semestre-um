import pandas as pd

# Carregar o arquivo original
df = pd.read_csv("importacao_filtrada.csv", sep=";")

# Mapeamento de códigos de município para nomes das cidades
mapa_cidades = {
    "3449904": "São José dos Campos",
    "3454102": "Taubaté",
    "3424402": "Jacareí",
    "3408504": "Caçapava"
}

# Criar nova coluna com os nomes das cidades
df["Cidade"] = df["CO_MUN"].astype(str).map(mapa_cidades)

# Visualizar algumas linhas
print(df[["CO_MUN", "Cidade", "SG_UF_MUN"]].head())

# Salvar resultado em novo CSV
df.to_csv("importacao_com_cidades.csv", sep=";", index=False)
