import pandas as pd

# Carregar o arquivo CSV
df = pd.read_csv("importação_21_25.csv", sep=";")

# Lista de códigos a filtrar
codigos = ["7606", "8108", "8803", "9301", "9306", "8526", "8710", "8802"]

# Filtrar apenas os registros desejados
df_filtrado = df[df["SH4"].astype(str).isin(codigos)]

# Mostrar resultado
print(df_filtrado)

# Se quiser salvar em CSV
df_filtrado.to_csv("importacao_filtrada.csv", sep=";", index=False)
