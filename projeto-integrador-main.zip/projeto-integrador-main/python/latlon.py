import pandas as pd
from geopy.geocoders import Nominatim
from time import sleep

# Carregar arquivo com encoding correto
df = pd.read_csv("Dados Auxiliares/PAIS.csv", encoding="latin1")

# Criar geocodificador
geolocator = Nominatim(user_agent="geoapi")

latitudes = []
longitudes = []

for country in df["NO_PAIS_ING"]:
    try:
        # Ignorar valores nulos
        if pd.isna(country):
            latitudes.append(None)
            longitudes.append(None)
            continue

        location = geolocator.geocode(country)

        if location:
            latitudes.append(location.latitude)
            longitudes.append(location.longitude)
        else:
            latitudes.append(None)
            longitudes.append(None)

    except Exception as e:
        print(f"Erro ao buscar '{country}': {e}")
        latitudes.append(None)
        longitudes.append(None)

    sleep(1)  # evita bloqueios do servidor

df["LAT"] = latitudes
df["LON"] = longitudes

# Exportar arquivo final
df.to_csv("PAIS_com_coordenadas.csv", index=False, encoding="utf-8")

print("Arquivo gerado: PAIS_com_coordenadas.csv")
