import pandas as pd

# Carregar o arquivo filtrado de SP
df = pd.read_csv("Importação/2021.csv", sep=";")

# Lista de CO_MUN que você quer separar
municipios = [3424402, 3408504, 3454102, 3449904]

# Filtrar as linhas
df_filtrado = df[df["CO_MUN"].isin(municipios)]

print("Total de linhas encontradas:", len(df_filtrado))

# Salvar em novo arquivo
df_filtrado.to_csv("Importação/filtrados/IMP_2021_MUN_F.csv", sep=";", index=False)
print("Arquivo salvo como IMP_2021_MUN_SP_F.csv")
