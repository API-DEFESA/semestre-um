import pandas as pd

# Lista dos arquivos
arquivos = {
    "2021": "Importação/filtrados/IMP_2021_MUN_F.csv",
    "2022": "Importação/filtrados/IMP_2022_MUN_F.csv",
    "2023": "Importação/filtrados/IMP_2023_MUN_F.csv",
    "2024": "Importação/filtrados/IMP_2024_MUN_F.csv",
    "2025": "Importação/filtrados/IMP_2025_MUN_F.csv"
}

# Lê e adiciona uma coluna 'ANO'
dfs = []
for ano, arq in arquivos.items():
    df = pd.read_csv(arq)
    df["ANO"] = ano   # adiciona coluna com o ano
    dfs.append(df)

# Junta tudo em um único DataFrame
df_final = pd.concat(dfs, ignore_index=True)

# Exporta para CSV
df_final.to_csv("IMP_2021_2025_UNIDOS.csv", index=False, encoding="utf-8-sig")

print("Arquivo gerado com sucesso!")
