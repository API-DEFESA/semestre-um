import pandas as pd

# Carregar o arquivo original
df = pd.read_csv("Dados principais/exportacao_21_25.csv", sep=";")

# Mapeamento de códigos de município para nomes dos itens
mapa_itens = {
    "8803": "Partes de aeronaves",
    "8802": "Aeronaves, helicópteros, aviões e outros veículos aéreos",
    "7606": "Chapas, folhas e tiras de alumínio",
    "8108": "Titânio e suas obras",
    "9301": "Armas de guerra",
    "9306": "Bombas, granadas, torpedos, minas, mísseis e semelhantes",
    "8526": "Aparelhos de radiodetecção, radionavegação ou radiotelecomando",
    "8710": "Tanques e outros veículos de combate blindados"
}

# Criar nova coluna com os nomes das cidades
df["ITENS"] = df["SH4"].astype(str).map(mapa_itens)

# Visualizar algumas linhas
print(df[["SH4", "ITENS"]].head())

# Salvar resultado em novo CSV
df.to_csv("exportacao_com_nomes.csv", sep=";", index=False)
