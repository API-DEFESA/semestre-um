import pandas as pd

# Caminhos dos seus arquivos originais
file_export = "Dados Primarios/exportacao_21_25.csv"
file_import = "Dados Primarios/importacao_21_25.csv"

# Ler os arquivos (separador ;)
df_export = pd.read_csv(file_export, sep=";")
df_import = pd.read_csv(file_import, sep=";")

# Adicionar coluna TIPO
df_export["TIPO"] = "Exportação"
df_import["TIPO"] = "Importação"

# Juntar os dois DataFrames
df_final = pd.concat([df_export, df_import], ignore_index=True)

# Salvar em um novo CSV
df_final.to_csv("import_export_21_25.csv", sep=";", index=False)

print("Arquivo unificado salvo como: import_export_21_25.csv")