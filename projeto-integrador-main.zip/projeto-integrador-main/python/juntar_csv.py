import pandas as pd
import unicodedata

# Lê o arquivo
df = pd.read_csv("Dados principais/projetinho.csv", sep=";")

coluna = "TIPO"

# Função para normalizar textos (remove acentos)
def normalizar(texto):
    texto = str(texto)
    texto = unicodedata.normalize('NFKD', texto).encode('ASCII', 'ignore').decode('utf-8')
    texto = texto.replace(" ", "_")  # troca espaços por _
    return texto

# Loop para criar arquivos por tipo
for valor in df[coluna].unique():
    df_filtrado = df[df[coluna] == valor]

    # Normaliza o nome do arquivo
    valor_limpo = normalizar(valor)

    nome_arquivo = f"{coluna}_{valor_limpo}.csv"

    df_filtrado.to_csv(nome_arquivo, sep=";", index=False)

    print(f"Arquivo criado: {nome_arquivo}")
